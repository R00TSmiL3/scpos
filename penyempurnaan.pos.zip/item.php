<?php
class item{
	var $id;
	var $name;
	var $price;
	var $description;
	var $quantity;
}
?>